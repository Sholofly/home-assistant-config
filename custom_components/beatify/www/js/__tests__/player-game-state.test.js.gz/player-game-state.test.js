/**
 * State-transition coverage for player-game.js (#1281).
 *
 * player-game.js is one of the large, logic-heavy, previously-untested state
 * files. These tests exercise the real round/control state machine — they
 * import the actual module (no re-implementation) and assert the observable
 * effects on DOM nodes / outgoing WebSocket messages:
 *
 *   - startCountdown / stopCountdown: timer text, warning/critical thresholds,
 *     and the post-deadline `round_timeout` watchdog nudges (#534 / freeze
 *     recovery).
 *   - updateControlBarState: PLAYING vs REVEAL vs other phase → which control
 *     buttons enable/disable and the label they show.
 *   - handleSongStopped / resetSongStoppedState: the Stop-Song toggle (Story 6.2)
 *     and the fact that updateControlBarState('PLAYING') resets a stopped song.
 *   - handleNextRound / resetNextRoundPending: the 2 s debounce latch (#534) that
 *     stops a double next-round send and re-arms on reset.
 *
 * Browser globals are stubbed for the node test env; player-utils.js and
 * player-reveal.js are mocked so the module loads in isolation.
 */
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// ---- browser-global stubs (must exist before the module is imported) --------
global.WebSocket = { OPEN: 1, CONNECTING: 0, CLOSED: 3 };
global.IntersectionObserver = class {
    observe() {}
    disconnect() {}
};
global.window = {
    BeatifyUtils: {
        // identity translator: returns the key so we can assert which label was set
        t: (key) => key,
    },
    matchMedia: () => ({ matches: true, addEventListener: () => {} }),
};

// Minimal element stub with classList + querySelector for nested label/icon spans.
function makeEl(id) {
    const classes = new Set();
    const children = {};
    const el = {
        id,
        textContent: '',
        disabled: false,
        _attrs: {},
        children,
        classList: {
            add: (...c) => c.forEach((x) => classes.add(x)),
            remove: (...c) => c.forEach((x) => classes.delete(x)),
            contains: (c) => classes.has(c),
            toggle: (c, on) => { if (on) classes.add(c); else classes.delete(c); return classes.has(c); },
        },
        setAttribute: (k, v) => { el._attrs[k] = v; },
        removeAttribute: (k) => { delete el._attrs[k]; },
        getAttribute: (k) => el._attrs[k],
        querySelector: (sel) => children[sel] || null,
    };
    return el;
}

let els;
global.document = {
    getElementById: (id) => els[id] || null,
};

vi.mock('../player-utils.js', () => {
    const state = { ws: null };
    return {
        state,
        escapeHtml: (s) => String(s),
        showConfirmModal: async () => true,
        prefersReducedMotion: () => true,
        animateValue: () => {},
        previousState: {},
        isPreviousStateInitialized: () => false,
        detectRankChanges: () => ({}),
        updatePreviousState: () => {},
        AnimationUtils: {},
        AnimationQueue: { isRunning: () => false, skipAll: () => {} },
        LEADERBOARD_LAZY_CONFIG: {},
        lazyLeaderboardState: {},
        initLeaderboardObserver: () => {},
        renderLazyLeaderboardRange: () => {},
        renderLeaderboardEntry: () => '',
        calculateInitialVisibleRange: () => [0, 0],
        setupLeaderboardResizeHandler: () => {},
        setEnergyLevel: () => {},
        triggerConfetti: () => {},
        stopConfetti: () => {},
    };
});

const utilsMod = await import('../player-utils.js');
const {
    startCountdown,
    stopCountdown,
    updateControlBarState,
    handleSongStopped,
    resetSongStoppedState,
    handleNextRound,
    resetNextRoundPending,
    setupReactionBar,
    resetReactionButtons,
    handleReactionAck,
    mayReactNow,
    syncInRoundReactionBar,
    waitingLine,
} = await import('../player-game.js');

const { REACTION_THROTTLE_SECONDS } = await import('../game-constants.js');

// helper: build a control button with a nested .control-label (+ optional icon)
function makeControlBtn(id, withIcon) {
    const btn = makeEl(id);
    btn.children['.control-label'] = makeEl();
    if (withIcon) btn.children['.control-icon'] = makeEl();
    return btn;
}

beforeEach(() => {
    els = {};
    utilsMod.state.ws = null;
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));
});

afterEach(() => {
    stopCountdown();
    vi.clearAllTimers();
    vi.useRealTimers();
});

describe('startCountdown / stopCountdown', () => {
    beforeEach(() => {
        els.timer = makeEl('timer');
        els['timer-neon'] = makeEl('timer-neon');
        els['timer-float'] = makeEl('timer-float');
        els['timer-float-num'] = makeEl('timer-float-num');
    });

    it('paints the initial remaining seconds and mirrors them onto the float pill', () => {
        startCountdown(Date.now() + 30_000);
        expect(els.timer.textContent).toBe(30);
        expect(els['timer-float-num'].textContent).toBe(30);
        // plenty of time left → neither warning nor critical
        expect(els.timer.classList.contains('timer--warning')).toBe(false);
        expect(els.timer.classList.contains('timer--critical')).toBe(false);
    });

    it('ticks down once per second', () => {
        startCountdown(Date.now() + 30_000);
        expect(els.timer.textContent).toBe(30);
        vi.advanceTimersByTime(3000);
        expect(els.timer.textContent).toBe(27);
    });

    it('applies the warning class at <=10s and critical at <=5s', () => {
        startCountdown(Date.now() + 11_000);
        expect(els.timer.classList.contains('timer--warning')).toBe(false);
        vi.advanceTimersByTime(1000); // now 10s
        expect(els.timer.classList.contains('timer--warning')).toBe(true);
        expect(els['timer-neon'].classList.contains('timer-neon--warn')).toBe(true);
        vi.advanceTimersByTime(5000); // now 5s
        expect(els.timer.classList.contains('timer--critical')).toBe(true);
        expect(els.timer.classList.contains('timer--warning')).toBe(false);
    });

    it('nudges the server with round_timeout once the deadline passes (watchdog #534)', () => {
        const sent = [];
        utilsMod.state.ws = { readyState: WebSocket.OPEN, send: (m) => sent.push(JSON.parse(m)) };
        startCountdown(Date.now() + 1000);
        expect(sent).toHaveLength(0);
        vi.advanceTimersByTime(1000); // hits 0 → first nudge
        expect(sent.filter((m) => m.type === 'round_timeout')).toHaveLength(1);
        // keeps nudging every 3 ticks past the deadline, not just once
        vi.advanceTimersByTime(3000);
        expect(sent.filter((m) => m.type === 'round_timeout').length).toBeGreaterThanOrEqual(2);
    });

    it('does not nudge while the socket is closed', () => {
        utilsMod.state.ws = { readyState: WebSocket.CLOSED, send: () => { throw new Error('should not send'); } };
        startCountdown(Date.now() + 1000);
        expect(() => vi.advanceTimersByTime(4000)).not.toThrow();
    });

    it('stopCountdown halts further ticks and hides the float', () => {
        startCountdown(Date.now() + 30_000);
        stopCountdown();
        const frozen = els.timer.textContent;
        vi.advanceTimersByTime(5000);
        expect(els.timer.textContent).toBe(frozen);
        expect(els['timer-float'].classList.contains('hidden')).toBe(true);
    });

    it('is a no-op (no throw) when the timer node is absent', () => {
        delete els.timer;
        expect(() => startCountdown(Date.now() + 5000)).not.toThrow();
    });

    // #1662 — clock-skew immunity. The countdown must derive remaining time from
    // the server's *relative* secondsRemaining anchored to the CLIENT's own
    // clock, NOT from subtracting the server wall-clock `deadline` from a
    // possibly-wrong client Date.now(). We simulate a badly skewed client: the
    // server's absolute deadline, if used directly, reads as long expired — yet
    // the server also reports 30s remaining, so the timer must show 30.
    it('derives remaining from server secondsRemaining, immune to a wrong client clock (#1662)', () => {
        // Client clock is 5 minutes AHEAD of the server: the server's real
        // deadline is 30s out, but expressed in the client's skewed frame it
        // looks 4.5 min in the PAST. Old code (deadline − Date.now()) → 0.
        const skewedServerDeadline = Date.now() - 5 * 60_000;
        startCountdown(skewedServerDeadline, 30);
        // Anchored to the relative 30s, not the bogus absolute deadline.
        expect(els.timer.textContent).toBe(30);
        // …and it still ticks down normally from the anchored value.
        vi.advanceTimersByTime(3000);
        expect(els.timer.textContent).toBe(27);
    });

    it('without secondsRemaining still honours the absolute deadline (back-compat)', () => {
        // No relative field → fall back to the server wall-clock deadline.
        startCountdown(Date.now() + 20_000);
        expect(els.timer.textContent).toBe(20);
    });
});

// #1273 AC#3 — V1 Smooth Correct. When a fresh state_update re-pushes a
// DIFFERENT authoritative deadline mid-round, the countdown must ease toward it
// (no hard jump) and flash a ghost-ring catch-up glow. requestAnimationFrame is
// absent in the default test env (so existing tests keep the simple path); here
// we install a manual rAF driver to step the ease deterministically.
describe('startCountdown smooth-correct on a re-pushed deadline (#1273)', () => {
    let rafCbs;
    beforeEach(() => {
        els.timer = makeEl('timer');
        els['timer-neon'] = makeEl('timer-neon');
        els['timer-float'] = makeEl('timer-float');
        els['timer-float-num'] = makeEl('timer-float-num');
        rafCbs = [];
        global.requestAnimationFrame = (cb) => { rafCbs.push(cb); return rafCbs.length; };
        global.cancelAnimationFrame = () => {};
    });
    afterEach(() => {
        delete global.requestAnimationFrame;
        delete global.cancelAnimationFrame;
    });

    // drain one queued rAF frame at the current (fake) time
    function flushFrame() {
        const cb = rafCbs.shift();
        if (cb) cb();
    }

    it('adopts a within-jitter deadline silently — no ease, no ghost-ring', () => {
        startCountdown(Date.now() + 30_000);
        expect(els.timer.textContent).toBe(30);
        // +200ms is below the 250ms threshold → silent adopt, no rAF armed
        startCountdown(Date.now() + 30_200);
        expect(rafCbs).toHaveLength(0);
        expect(els['timer-neon'].classList.contains('timer-neon--catchup')).toBe(false);
    });

    it('eases (does not hard-jump) and lands on the server value for real drift', () => {
        startCountdown(Date.now() + 30_000); // shows 30
        // server says there are really 25s left (5s of drift) → must NOT snap
        startCountdown(Date.now() + 25_000);
        // ease armed + ghost-ring on
        expect(rafCbs.length).toBeGreaterThan(0);
        expect(els['timer-neon'].classList.contains('timer-neon--catchup')).toBe(true);
        // first eased frame at t≈0 is still near the old value (no instant 30→25 jump)
        flushFrame();
        expect(els.timer.textContent).toBeGreaterThan(25);
        // after the ease window elapses, the final frame settles exactly on 25
        vi.advanceTimersByTime(400);
        // run remaining queued frames until the ease completes
        for (let i = 0; i < 10 && rafCbs.length; i++) flushFrame();
        expect(els.timer.textContent).toBe(25);
        expect(els['timer-neon'].classList.contains('timer-neon--catchup')).toBe(false);
    });

    it('the interval keeps ticking from the corrected deadline afterwards', () => {
        startCountdown(Date.now() + 30_000);
        startCountdown(Date.now() + 25_000);
        vi.advanceTimersByTime(400);
        for (let i = 0; i < 10 && rafCbs.length; i++) flushFrame();
        expect(els.timer.textContent).toBe(25);
        // the underlying 1s interval still runs — it ticks down from 25
        vi.advanceTimersByTime(2000);
        expect(els.timer.textContent).toBe(23);
    });

    it('stopCountdown clears the ghost-ring and ease state', () => {
        startCountdown(Date.now() + 30_000);
        startCountdown(Date.now() + 25_000);
        expect(els['timer-neon'].classList.contains('timer-neon--catchup')).toBe(true);
        stopCountdown();
        expect(els['timer-neon'].classList.contains('timer-neon--catchup')).toBe(false);
    });
});

describe('updateControlBarState', () => {
    beforeEach(() => {
        els['stop-song-btn'] = makeControlBtn('stop-song-btn', true);
        els['next-round-admin-btn'] = makeControlBtn('next-round-admin-btn');
        els['end-game-btn'] = makeControlBtn('end-game-btn');
    });

    it('PLAYING enables stop + next (labelled skip) and re-enables End', () => {
        // pre-disable End to prove it gets reset
        els['end-game-btn'].disabled = true;
        els['end-game-btn'].classList.add('is-disabled');

        updateControlBarState('PLAYING');

        const next = els['next-round-admin-btn'];
        expect(next.disabled).toBe(false);
        expect(next.classList.contains('is-disabled')).toBe(false);
        expect(next.querySelector('.control-label').textContent).toBe('game.skip');
        expect(els['stop-song-btn'].disabled).toBe(false);
        expect(els['end-game-btn'].disabled).toBe(false);
        expect(els['end-game-btn'].classList.contains('is-disabled')).toBe(false);
    });

    it('REVEAL labels the next button "next" and keeps it enabled', () => {
        updateControlBarState('REVEAL');
        const next = els['next-round-admin-btn'];
        expect(next.disabled).toBe(false);
        expect(next.querySelector('.control-label').textContent).toBe('game.next');
    });

    it('any other phase disables the next button', () => {
        updateControlBarState('LOBBY');
        const next = els['next-round-admin-btn'];
        expect(next.disabled).toBe(true);
        expect(next.classList.contains('is-disabled')).toBe(true);
    });

    it('PLAYING of a NEW round resets a previously stopped song back to active', () => {
        // #3053: only a round change resets — a same-round frame must not.
        handleSongStopped();
        expect(els['stop-song-btn'].disabled).toBe(true);
        updateControlBarState('PLAYING', { round: 9001, song_stopped: false });
        expect(els['stop-song-btn'].disabled).toBe(false);
        expect(els['stop-song-btn'].classList.contains('is-stopped')).toBe(false);
    });
});

describe('handleSongStopped / resetSongStoppedState (Story 6.2)', () => {
    beforeEach(() => {
        els['stop-song-btn'] = makeControlBtn('stop-song-btn', true);
    });

    it('marks the button stopped + disabled with a checkmark', () => {
        handleSongStopped();
        const btn = els['stop-song-btn'];
        expect(btn.disabled).toBe(true);
        expect(btn.classList.contains('is-stopped')).toBe(true);
        expect(btn.classList.contains('is-disabled')).toBe(true);
        expect(btn.querySelector('.control-icon').textContent).toBe('✓');
        expect(btn.querySelector('.control-label').textContent).toBe('game.stopped');
    });

    it('reset clears the stopped state and restores the stop icon', () => {
        handleSongStopped();
        resetSongStoppedState();
        const btn = els['stop-song-btn'];
        expect(btn.disabled).toBe(false);
        expect(btn.classList.contains('is-stopped')).toBe(false);
        expect(btn.querySelector('.control-icon').textContent).toBe('⏹️');
        expect(btn.querySelector('.control-label').textContent).toBe('game.stop');
    });
});

describe('handleNextRound / resetNextRoundPending debounce (#534)', () => {
    beforeEach(() => {
        els['next-round-btn'] = makeEl('next-round-btn');
        els['next-round-admin-btn'] = makeControlBtn('next-round-admin-btn');
        // `nextRoundPending` is module-level state; clear it so the latch from a
        // prior test (whose 10s safety timeout got flushed in afterEach) doesn't
        // bleed in and swallow this test's first click.
        resetNextRoundPending();
    });

    function wireSocket() {
        const sent = [];
        utilsMod.state.ws = { readyState: WebSocket.OPEN, send: (m) => sent.push(JSON.parse(m)) };
        return sent;
    }

    it('sends exactly one next_round and latches the buttons disabled', () => {
        const sent = wireSocket();
        handleNextRound();
        expect(sent.filter((m) => m.action === 'next_round')).toHaveLength(1);
        expect(els['next-round-btn'].disabled).toBe(true);
        expect(els['next-round-admin-btn'].disabled).toBe(true);
    });

    it('swallows a rapid second click while pending', () => {
        const sent = wireSocket();
        handleNextRound();
        handleNextRound();
        expect(sent.filter((m) => m.action === 'next_round')).toHaveLength(1);
    });

    it('re-arms after the 10s safety timeout fires', () => {
        const sent = wireSocket();
        handleNextRound();
        vi.advanceTimersByTime(10_000); // safety timeout → resetNextRoundPending
        handleNextRound();
        expect(sent.filter((m) => m.action === 'next_round')).toHaveLength(2);
    });

    it('resetNextRoundPending re-enables the buttons and allows another send', () => {
        const sent = wireSocket();
        handleNextRound();
        resetNextRoundPending();
        expect(els['next-round-btn'].disabled).toBe(false);
        handleNextRound();
        expect(sent.filter((m) => m.action === 'next_round')).toHaveLength(2);
    });

    it('does nothing when the socket is not open', () => {
        utilsMod.state.ws = { readyState: WebSocket.CLOSED, send: () => { throw new Error('no send'); } };
        expect(() => handleNextRound()).not.toThrow();
    });
});

// ---------------------------------------------------------------------------
// #1757 / #2562: reaction bar.
//
// #1757 established that a tap counts as spent only when it actually leaves the
// socket. #2562 replaced the one-per-reveal-phase budget with a time throttle,
// so what is asserted below is the cooldown: a burst reaches the wire once, the
// server's ack decides how long the bar stays dead, and the bar re-arms itself.
// ---------------------------------------------------------------------------

function makeReactionBtn(emoji) {
    const classes = new Set();
    let clickHandler = null;
    return {
        disabled: false,
        _attrs: { 'data-emoji': emoji },
        classList: {
            add: (c) => classes.add(c),
            remove: (c) => classes.delete(c),
            contains: (c) => classes.has(c),
            toggle: (c, on) => { if (on) classes.add(c); else classes.delete(c); return classes.has(c); },
        },
        getAttribute: function (k) { return this._attrs[k]; },
        setAttribute: function (k, v) { this._attrs[k] = v; },
        addEventListener: (type, fn) => { if (type === 'click') clickHandler = fn; },
        click: () => { if (clickHandler) clickHandler(); },
    };
}

describe('reaction bar (#1757 / #2562)', () => {
    let buttons;
    let sent;

    beforeEach(() => {
        buttons = [makeReactionBtn('🔥'), makeReactionBtn('😂')];
        els['reaction-bar'] = { querySelectorAll: () => buttons };
        els['reaction-cooldown'] = makeEl('reaction-cooldown');
        els['reaction-cooldown-fill'] = makeEl('reaction-cooldown-fill');
        els['reaction-cooldown-fill'].style = {};
        sent = [];
        utilsMod.state.reactionCooldownUntil = 0;
    });

    function openSocket() {
        utilsMod.state.ws = { readyState: WebSocket.OPEN, send: (m) => sent.push(JSON.parse(m)) };
        setupReactionBar();
    }

    it('does NOT start a cooldown or disable buttons when the socket is closed', () => {
        utilsMod.state.ws = { readyState: WebSocket.CLOSED, send: () => { throw new Error('no send'); } };
        setupReactionBar();
        buttons[0].click();
        expect(utilsMod.state.reactionCooldownUntil).toBe(0); // still allowed
        expect(buttons[0].disabled).toBe(false);
        expect(buttons[0].classList.contains('is-used')).toBe(false);
    });

    it('sends the reaction, lights the tapped emoji and goes on cooldown', () => {
        openSocket();
        buttons[0].click();

        expect(sent).toEqual([{ type: 'reaction', emoji: '🔥' }]);
        // whole bar disabled; chosen emoji lit + aria-pressed
        expect(buttons[0].disabled).toBe(true);
        expect(buttons[1].disabled).toBe(true);
        expect(buttons[0].classList.contains('is-used')).toBe(true);
        expect(buttons[0].getAttribute('aria-pressed')).toBe('true');
        expect(buttons[1].getAttribute('aria-pressed')).toBe('false');
    });

    it('swallows a burst — only the first tap reaches the wire', () => {
        openSocket();
        for (let i = 0; i < 10; i++) buttons[i % 2].click();
        expect(sent).toHaveLength(1);
    });

    it('re-arms itself once the throttle interval has passed', () => {
        openSocket();
        buttons[0].click();

        vi.advanceTimersByTime(REACTION_THROTTLE_SECONDS * 1000 - 1);
        buttons[1].click();
        expect(sent).toHaveLength(1);
        expect(buttons[0].disabled).toBe(true);

        vi.advanceTimersByTime(1);
        expect(buttons[0].disabled).toBe(false);
        expect(buttons[0].classList.contains('is-used')).toBe(false);
        buttons[1].click();
        expect(sent).toHaveLength(2);
    });

    it('shows the cooldown line while the bar is dead and hides it after', () => {
        // A tap that vanishes with no visible reason reads as a broken button.
        openSocket();
        buttons[0].click();
        expect(els['reaction-cooldown'].classList.contains('hidden')).toBe(false);

        vi.advanceTimersByTime(REACTION_THROTTLE_SECONDS * 1000);
        expect(els['reaction-cooldown'].classList.contains('hidden')).toBe(true);
    });

    it("re-anchors the cooldown on the server's remaining time", () => {
        // The server is the one enforcing the throttle; a throttled ack carries
        // what is actually left, which may be more than the client assumed.
        openSocket();
        buttons[0].click();
        handleReactionAck({ retry_after: REACTION_THROTTLE_SECONDS + 4, throttled: true });

        vi.advanceTimersByTime(REACTION_THROTTLE_SECONDS * 1000);
        expect(buttons[0].disabled).toBe(true);
        vi.advanceTimersByTime(4000);
        expect(buttons[0].disabled).toBe(false);
    });

    it('an ack with no time left re-arms the bar immediately', () => {
        openSocket();
        buttons[0].click();
        handleReactionAck({ retry_after: 0, throttled: false });
        expect(buttons[0].disabled).toBe(false);
        expect(els['reaction-cooldown'].classList.contains('hidden')).toBe(true);
    });

    it('resetReactionButtons re-enables the bar', () => {
        openSocket();
        buttons[0].click();
        expect(buttons[0].disabled).toBe(true);

        resetReactionButtons();
        expect(buttons[0].disabled).toBe(false);
        expect(buttons[0].classList.contains('is-used')).toBe(false);
        expect(buttons[0].getAttribute('aria-pressed')).toBe('false');
    });
});

// ---------------------------------------------------------------------------
// #2562: who may react, and when the bar is on screen.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// #2562: the waiting line — who the room is still waiting for, not how many.
// ---------------------------------------------------------------------------

describe('waitingLine (#2562)', () => {
    /** Swap in a translator that actually renders the placeholders. */
    function withCopy(fn) {
        const original = global.window.BeatifyUtils.t;
        global.window.BeatifyUtils.t = (key, vars) => {
            const copy = {
                'game.lockedInAllSubmitted': 'Locked in \u00b7 everyone submitted',
                'game.lockedInWaitingOne': 'Locked in \u00b7 {name} is still thinking',
                'game.lockedInWaitingTwo': 'Locked in \u00b7 {first} and {second} are thinking',
                'game.lockedInWaitingCount': 'Locked in \u00b7 waiting for {count} more',
            }[key];
            if (!copy) return key;
            return copy.replace(/\{(\w+)\}/g, (_, name) => String((vars || {})[name]));
        };
        try {
            return fn();
        } finally {
            global.window.BeatifyUtils.t = original;
        }
    }

    const p = (name, submitted) => ({ name, submitted });

    it('names the one player still thinking', () => {
        withCopy(() => {
            expect(waitingLine([p('Markus', false), p('Lena', true)]))
                .toBe('Locked in \u00b7 Markus is still thinking');
        });
    });

    it('names both when two are left', () => {
        withCopy(() => {
            expect(waitingLine([p('Markus', false), p('Lena', false), p('Jan', true)]))
                .toBe('Locked in \u00b7 Markus and Lena are thinking');
        });
    });

    it('falls back to the count from three on', () => {
        // Three names is longer than the banner has room for, and listing them
        // properly would need per-locale list grammar.
        withCopy(() => {
            expect(waitingLine([p('A', false), p('B', false), p('C', false)]))
                .toBe('Locked in \u00b7 waiting for 3 more');
        });
    });

    it('says everyone is in when nobody is left', () => {
        withCopy(() => {
            expect(waitingLine([p('Markus', true), p('Lena', true)]))
                .toBe('Locked in \u00b7 everyone submitted');
        });
    });
});

describe('mayReactNow (#2562)', () => {
    it('lets everyone react at the reveal', () => {
        expect(mayReactNow('REVEAL', { submitted: false })).toBe(true);
        expect(mayReactNow('REVEAL', null)).toBe(true);
    });

    it('keeps a player who is still guessing out of it', () => {
        expect(mayReactNow('PLAYING', { submitted: false })).toBe(false);
    });

    it('opens up once the player has submitted', () => {
        expect(mayReactNow('PLAYING', { submitted: true })).toBe(true);
    });

    it('opens up for players who are out of the round', () => {
        // #827 already showed them the bar; the server used to drop the taps.
        expect(mayReactNow('PLAYING', { eliminated: true })).toBe(true);
        expect(mayReactNow('PLAYING', { playoff_spectator: true })).toBe(true);
    });

    it('stays shut in every other phase', () => {
        for (const phase of ['LOBBY', 'PAUSED', 'END']) {
            expect(mayReactNow(phase, { submitted: true })).toBe(false);
        }
    });
});

describe('syncInRoundReactionBar (#2562)', () => {
    beforeEach(() => {
        els['reaction-bar'] = makeEl('reaction-bar');
        els['reaction-bar'].querySelectorAll = () => [];
        utilsMod.state.playerName = 'Alice';
    });

    it('hides the bar while the player is still guessing', () => {
        syncInRoundReactionBar({ players: [{ name: 'Alice', submitted: false }] });
        expect(els['reaction-bar'].classList.contains('hidden')).toBe(true);
    });

    it('shows the bar once the player has submitted', () => {
        syncInRoundReactionBar({ players: [{ name: 'Alice', submitted: true }] });
        expect(els['reaction-bar'].classList.contains('hidden')).toBe(false);
    });
});
