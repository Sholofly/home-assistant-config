/**
 * Unit tests for wizard.js pure helpers.
 * These helpers drive the state machine: when to show, where to resume, when to show the pill.
 */
import { describe, it, expect, beforeEach } from 'vitest';
import { resumeAtStep, shouldTrigger, shouldShowPill, providerSupportedForPlayer, capabilityBadgeForPlayer, applyGameModeTogglePrecedence, difficultyDisplayFor, buildWizChip, resolveGameLanguageDefault, buildTtsPayload, modeHintHtml, doneSummaryHtml, buildLightsPayload } from '../wizard.js';

function makeLS(initial = {}) {
    const store = { ...initial };
    return {
        getItem: (k) => (k in store ? store[k] : null),
        setItem: (k, v) => { store[k] = String(v); },
        removeItem: (k) => { delete store[k]; },
        _store: store,
    };
}

// ------------------------------------------------------------------
// resumeAtStep — first incomplete required step (1-4) or null when done
// ------------------------------------------------------------------
describe('resumeAtStep', () => {
    it('returns 1 on a fresh install (no state, no player)', () => {
        expect(resumeAtStep(makeLS())).toBe(1);
    });

    it('returns 2 when speaker is saved but no provider yet', () => {
        const ls = makeLS({ beatify_last_player: 'media_player.sonos' });
        expect(resumeAtStep(ls)).toBe(2);
    });

    it('returns 3 when speaker + provider are saved', () => {
        const ls = makeLS({
            beatify_last_player: 'media_player.sonos',
            beatify_game_settings: JSON.stringify({ provider: 'spotify' }),
        });
        expect(resumeAtStep(ls)).toBe(3);
    });

    it('returns null when wizard is marked done', () => {
        const ls = makeLS({ beatify_wizard_state: 'done' });
        expect(resumeAtStep(ls)).toBeNull();
    });

    it('respects explicit wizard state over inferred signals', () => {
        const ls = makeLS({
            beatify_wizard_state: 'step4',
            beatify_last_player: 'media_player.sonos',
        });
        expect(resumeAtStep(ls)).toBe(4);
    });

    it('treats malformed game_settings JSON as no provider', () => {
        const ls = makeLS({
            beatify_last_player: 'media_player.sonos',
            beatify_game_settings: '{not valid json',
        });
        expect(resumeAtStep(ls)).toBe(2);
    });
});

// ------------------------------------------------------------------
// shouldTrigger — decides whether wizard opens on admin load
// ------------------------------------------------------------------
describe('shouldTrigger', () => {
    it('returns true on a fresh install (no state, no player saved)', () => {
        expect(shouldTrigger(makeLS())).toBe(true);
    });

    it('returns false when the user has marked it done', () => {
        expect(shouldTrigger(makeLS({ beatify_wizard_state: 'done' }))).toBe(false);
    });

    it('returns false when user explicitly dismissed', () => {
        expect(shouldTrigger(makeLS({ beatify_wizard_state: 'dismissed' }))).toBe(false);
    });

    it('returns true when user is mid-wizard (step2)', () => {
        expect(shouldTrigger(makeLS({ beatify_wizard_state: 'step2' }))).toBe(true);
    });

    it('returns false when no wizard state but admin has already been used (speaker saved)', () => {
        // Someone who ignored the wizard the first time and configured via admin directly
        const ls = makeLS({ beatify_last_player: 'media_player.sonos' });
        expect(shouldTrigger(ls)).toBe(false);
    });

    it('survives localStorage being unavailable (private mode)', () => {
        const brokenLs = { getItem: () => { throw new Error('denied'); } };
        // Broken localStorage → no flags visible → behave as fresh install
        expect(shouldTrigger(brokenLs)).toBe(true);
    });
});

// ------------------------------------------------------------------
// shouldShowPill — "Finish setup" pill in admin header
// ------------------------------------------------------------------
describe('shouldShowPill', () => {
    it('returns false when user never used the wizard', () => {
        expect(shouldShowPill(makeLS())).toBe(false);
    });

    it('returns true when dismissed AND required steps are incomplete', () => {
        const ls = makeLS({ beatify_wizard_state: 'dismissed' });
        expect(shouldShowPill(ls)).toBe(true);
    });

    it('returns false when dismissed but all required steps were done via admin later', () => {
        const ls = makeLS({
            beatify_wizard_state: 'dismissed',
            beatify_last_player: 'media_player.sonos',
            beatify_game_settings: JSON.stringify({ provider: 'spotify' }),
        });
        // resumeAtStep returns 3 here (speaker + provider done, but no 'done' flag) — pill stays up
        // to remind them to complete. This asserts the current behavior.
        expect(shouldShowPill(ls)).toBe(true);
    });

    it('returns false when wizard is done', () => {
        expect(shouldShowPill(makeLS({ beatify_wizard_state: 'done' }))).toBe(false);
    });

    it('returns false when user is still mid-wizard (not dismissed)', () => {
        expect(shouldShowPill(makeLS({ beatify_wizard_state: 'step2' }))).toBe(false);
    });
});

// ------------------------------------------------------------------
// providerSupportedForPlayer — gates the Step 2 chip state (#772)
// ------------------------------------------------------------------
describe('providerSupportedForPlayer', () => {
    it('returns true when no player is selected yet (Step 2 before Step 1)', () => {
        expect(providerSupportedForPlayer(null, 'apple_music')).toBe(true);
    });

    it('returns true when the player record flags the provider as supported', () => {
        const player = { supports_spotify: true, supports_apple_music: true };
        expect(providerSupportedForPlayer(player, 'spotify')).toBe(true);
    });

    it('returns false when the player record explicitly denies the provider (Sonos + Apple Music)', () => {
        const player = { supports_spotify: true, supports_apple_music: false };
        expect(providerSupportedForPlayer(player, 'apple_music')).toBe(false);
    });

    it('treats a missing supports_* field as supported (forward-compat for new providers)', () => {
        const player = { supports_spotify: true };
        expect(providerSupportedForPlayer(player, 'deezer')).toBe(true);
    });
});

// ------------------------------------------------------------------
// capabilityBadgeForPlayer — Step 1 speaker-row badge (#772)
// ------------------------------------------------------------------
describe('capabilityBadgeForPlayer', () => {
    const providers = [
        { id: 'spotify', label: 'Spotify' },
        { id: 'apple_music', label: 'Apple Music' },
        { id: 'youtube_music', label: 'YouTube Music' },
    ];

    it('returns null when no player is provided', () => {
        expect(capabilityBadgeForPlayer(null, providers)).toBeNull();
    });

    it('returns a full/green badge when every provider is supported', () => {
        const player = { supports_spotify: true, supports_apple_music: true, supports_youtube_music: true };
        expect(capabilityBadgeForPlayer(player, providers)).toEqual({ cls: 'full', label: 'All services' });
    });

    it('returns a partial/orange "X only" badge for a single supported provider (Sonos case)', () => {
        const player = { supports_spotify: true, supports_apple_music: false, supports_youtube_music: false };
        expect(capabilityBadgeForPlayer(player, providers)).toEqual({ cls: 'partial', label: 'Spotify only' });
    });

    it('respects locale word order via onlyTemplate (German prefixes "nur")', () => {
        const player = { supports_spotify: true, supports_apple_music: false, supports_youtube_music: false };
        const badge = capabilityBadgeForPlayer(player, providers, { onlyTemplate: 'nur {provider}' });
        expect(badge).toEqual({ cls: 'partial', label: 'nur Spotify' });
    });

    it('lists both services (muted summary) for a two-service subset, full list on title (#1319)', () => {
        const player = { supports_spotify: true, supports_apple_music: true, supports_youtube_music: false };
        expect(capabilityBadgeForPlayer(player, providers)).toEqual({
            cls: 'summary',
            label: 'Spotify, Apple Music',
            title: 'Spotify, Apple Music',
        });
    });

    it('returns a none badge when no provider is supported (e.g. cast without MA)', () => {
        const player = { supports_spotify: false, supports_apple_music: false, supports_youtube_music: false };
        expect(capabilityBadgeForPlayer(player, providers)).toEqual({ cls: 'none', label: 'No services' });
    });

    it('uses provided i18n labels when given', () => {
        const player = { supports_spotify: true, supports_apple_music: true, supports_youtube_music: true };
        const badge = capabilityBadgeForPlayer(player, providers, { all: 'Alle Dienste' });
        expect(badge.label).toBe('Alle Dienste');
    });

    // #1319: with the real 6-provider universe, multi-service rows must collapse
    // to a single short, muted line instead of a wrapping uppercase comma list.
    describe('summarization over the full 6-provider set (#1319)', () => {
        const six = [
            { id: 'spotify', label: 'Spotify' },
            { id: 'apple_music', label: 'Apple Music' },
            { id: 'youtube_music', label: 'YouTube Music' },
            { id: 'tidal', label: 'Tidal' },
            { id: 'deezer', label: 'Deezer' },
            { id: 'amazon_music', label: 'Amazon Music' },
        ];

        it('collapses the typical MA player (5 of 6, all but Amazon) to "All major services"', () => {
            const player = {
                supports_spotify: true, supports_apple_music: true, supports_youtube_music: true,
                supports_tidal: true, supports_deezer: true, supports_amazon_music: false,
            };
            expect(capabilityBadgeForPlayer(player, six)).toEqual({
                cls: 'summary',
                label: 'All major services',
                title: 'Spotify, Apple Music, YouTube Music, Tidal, Deezer',
            });
        });

        it('collapses 3 of 6 to "first +N" with the full list on title', () => {
            const player = {
                supports_spotify: true, supports_apple_music: true, supports_youtube_music: true,
                supports_tidal: false, supports_deezer: false, supports_amazon_music: false,
            };
            expect(capabilityBadgeForPlayer(player, six)).toEqual({
                cls: 'summary',
                label: 'Spotify +2',
                title: 'Spotify, Apple Music, YouTube Music',
            });
        });

        it('keeps the single-service accent badge (cls partial) even in the 6-provider set', () => {
            const player = {
                supports_spotify: true, supports_apple_music: false, supports_youtube_music: false,
                supports_tidal: false, supports_deezer: false, supports_amazon_music: false,
            };
            expect(capabilityBadgeForPlayer(player, six)).toEqual({ cls: 'partial', label: 'Spotify only' });
        });

        it('respects custom summary templates (locale)', () => {
            const player = {
                supports_spotify: true, supports_apple_music: true, supports_youtube_music: true,
                supports_tidal: false, supports_deezer: false, supports_amazon_music: false,
            };
            const badge = capabilityBadgeForPlayer(player, six, { moreTemplate: '{provider} und {count} weitere' });
            expect(badge.label).toBe('Spotify und 2 weitere');
        });
    });
});

// ------------------------------------------------------------------
// applyGameModeTogglePrecedence — Step 4 mutual exclusion (#1180)
//
// The load-bearing requirement: enabling Title & Artist mode must NOT zero the
// year-round bonus flags. The wizard writes these flags verbatim into
// beatify_game_settings on every advance past Step 4, and admin.js reads that
// same key — so zeroing them here would silently destroy the host's saved
// bonus choices on the next admin reload (the exact regression admin.js's
// applyTitleArtistBonusPrecedence contract guards against). Exclusivity is
// asymmetric: TA is the replaceable round, so turning a year bonus on exits TA,
// but turning TA on leaves the year flags untouched (suppression is applied
// later, at start-game-payload build time in admin.js).
// ------------------------------------------------------------------
describe('applyGameModeTogglePrecedence', () => {
    const allYearOn = {
        artistChallenge: true,
        movieQuiz: true,
        introMode: true,
        closestWinsMode: true,
        titleArtistMode: false,
    };

    it('does NOT zero the year-round flags when TA mode is turned on', () => {
        const out = applyGameModeTogglePrecedence(allYearOn, 'titleArtist', true);
        expect(out).toEqual({
            artistChallenge: true,
            movieQuiz: true,
            introMode: true,
            closestWinsMode: true,
            titleArtistMode: true,
        });
    });

    it('turns TA mode off when a year-distance bonus (artist/closest) is turned on', () => {
        // #1180: only the year-distance modes (artist challenge, closest wins)
        // are mutually exclusive with TA. Movie quiz + intro are compatible
        // bonuses and leave titleArtistMode untouched (see the movie/intro
        // compatibility tests below), so they're deliberately excluded here.
        const taOn = { ...allYearOn, artistChallenge: false, movieQuiz: false, introMode: false, closestWinsMode: false, titleArtistMode: true };
        for (const [key, flag] of [
            ['artist', 'artistChallenge'],
            ['closest', 'closestWinsMode'],
        ]) {
            const out = applyGameModeTogglePrecedence(taOn, key, true);
            expect(out[flag]).toBe(true);
            expect(out.titleArtistMode).toBe(false);
        }
    });

    it('keeps TA mode on when a compatible bonus (movie/intro) is turned on', () => {
        const taOn = { artistChallenge: false, movieQuiz: false, introMode: false, closestWinsMode: false, titleArtistMode: true };
        for (const [key, flag] of [
            ['movie', 'movieQuiz'],
            ['intro', 'introMode'],
        ]) {
            const out = applyGameModeTogglePrecedence(taOn, key, true);
            expect(out[flag]).toBe(true);
            expect(out.titleArtistMode).toBe(true);
        }
    });

    it('does NOT touch TA mode when a year-round bonus is turned off', () => {
        const taOn = { artistChallenge: false, movieQuiz: false, introMode: false, closestWinsMode: false, titleArtistMode: true };
        const out = applyGameModeTogglePrecedence(taOn, 'artist', false);
        expect(out.artistChallenge).toBe(false);
        expect(out.titleArtistMode).toBe(true); // turning a bonus OFF must not exit TA
    });

    it('does not mutate the input object (source of truth survives)', () => {
        const flags = { ...allYearOn };
        const snapshot = { ...flags };
        applyGameModeTogglePrecedence(flags, 'titleArtist', true);
        expect(flags).toEqual(snapshot);
    });

    it('returns a new object reference', () => {
        expect(applyGameModeTogglePrecedence(allYearOn, 'titleArtist', true)).not.toBe(allYearOn);
    });
});

// ------------------------------------------------------------------
// Persist → hydrate round-trip: enabling TA must NOT persist false over a
// previously-true year-round bonus (#1180).
//
// This models the wizard's beatify_game_settings contract:
//   - _persistGameSettings() merges the chosen* flags into the stored object
//     under keys { artistChallenge, movieQuiz, introMode, closestWinsMode,
//     titleArtistMode } (wizard.js).
//   - On the next admin load, admin.js's loadSavedSettings() reads those keys
//     straight back. The wizard's own show()/hydration reads them too.
//   - Toggle precedence runs through applyGameModeTogglePrecedence.
// The previous bug zeroed the year flags when TA was enabled, persisting false
// and destroying the host's choices on the next admin reload. This is the
// regression guard for that.
// ------------------------------------------------------------------
describe('wizard TA enable → persist → reload does not destroy bonus choices', () => {
    // Mirror of _persistGameSettings()'s merge shape (only the Step-4 flags).
    function persist(ls, flags) {
        const raw = ls.getItem('beatify_game_settings');
        const existing = raw ? JSON.parse(raw) : {};
        ls.setItem('beatify_game_settings', JSON.stringify({
            ...existing,
            artistChallenge: flags.artistChallenge,
            movieQuiz: flags.movieQuiz,
            introMode: flags.introMode,
            closestWinsMode: flags.closestWinsMode,
            titleArtistMode: flags.titleArtistMode,
        }));
    }

    // Mirror of the wizard / admin hydration: read flags straight back.
    function hydrate(ls) {
        const s = JSON.parse(ls.getItem('beatify_game_settings'));
        return {
            artistChallenge: s.artistChallenge,
            movieQuiz: s.movieQuiz,
            introMode: s.introMode,
            closestWinsMode: s.closestWinsMode,
            titleArtistMode: s.titleArtistMode,
        };
    }

    it('keeps a previously-true Artist Challenge after enabling TA, persisting, reloading, then disabling TA', () => {
        const ls = makeLS();

        // Host has Artist Challenge ON, TA off. Wizard advances past Step 4.
        let flags = {
            artistChallenge: true,
            movieQuiz: false,
            introMode: false,
            closestWinsMode: false,
            titleArtistMode: false,
        };
        persist(ls, flags);

        // Host taps the TA card ON in the wizard.
        flags = applyGameModeTogglePrecedence(flags, 'titleArtist', true);
        // The bonus flag must NOT have been zeroed by the toggle...
        expect(flags.artistChallenge).toBe(true);
        persist(ls, flags);
        // ...and must NOT be persisted as false.
        expect(JSON.parse(ls.getItem('beatify_game_settings')).artistChallenge).toBe(true);

        // Reload admin (no wizard mutation): the stored choice survives.
        flags = hydrate(ls);
        expect(flags.titleArtistMode).toBe(true);
        expect(flags.artistChallenge).toBe(true);

        // Host turns TA off again (e.g. via admin) → Artist Challenge restored.
        flags = applyGameModeTogglePrecedence(flags, 'titleArtist', false);
        persist(ls, flags);
        flags = hydrate(ls);
        expect(flags.titleArtistMode).toBe(false);
        expect(flags.artistChallenge).toBe(true);
    });
});

// ------------------------------------------------------------------
// difficultyDisplayFor — difficulty area depends on the core mode
// ------------------------------------------------------------------
describe('difficultyDisplayFor', () => {
    it('shows the year-distance chips and no summary in Jahr mode', () => {
        expect(difficultyDisplayFor(false)).toEqual({ showChips: true, summaryKey: null });
    });

    it('hides the chips and shows the T&I scoring summary in Title & Artist mode', () => {
        expect(difficultyDisplayFor(true)).toEqual({
            showChips: false,
            summaryKey: 'wizard.step4.taScoring',
        });
    });
});

// buildWizChip — Light Mode chip markup contract (#1228 regression)
// ------------------------------------------------------------------
describe('buildWizChip', () => {
    it('emits a kebab-case data-light-mode attribute (matches the [data-light-mode] binding)', () => {
        const html = buildWizChip('static', 'Static', 'light-mode', 'dynamic');
        // The exact attribute that broke before: must be data-light-mode, not
        // data-lightMode. The browser maps data-light-mode -> dataset.lightMode
        // by spec, so locking the kebab attribute name guards the whole binding.
        expect(html).toContain('data-light-mode="static"');
        expect(html).not.toContain('data-lightMode');
    });

    it('marks the active chip and only the active chip', () => {
        expect(buildWizChip('static', 'Static', 'light-mode', 'static')).toContain('wiz-chip active');
        expect(buildWizChip('dynamic', 'Dynamic', 'light-mode', 'static')).not.toContain('active');
    });

    it('works for the intensity group too', () => {
        expect(buildWizChip('party', 'Party', 'intensity', 'party')).toContain('data-intensity="party"');
    });
});

// ------------------------------------------------------------------
// resolveGameLanguageDefault — game language must follow the browser
// locale on EVERY wizard open, including a first-time user with no
// saved settings (#1354: German wizard but English game).
// ------------------------------------------------------------------
describe('resolveGameLanguageDefault', () => {
    it('uses the browser language even when there are NO saved settings (#1354)', () => {
        // The bug: first-time user, no beatify_game_settings → game went out
        // as the hard-coded 'en' default while the wizard UI was German.
        expect(resolveGameLanguageDefault(() => 'de', null, 'en')).toBe('de');
    });

    it('browser language wins over a stale saved language', () => {
        expect(resolveGameLanguageDefault(() => 'de', { language: 'en' }, 'en')).toBe('de');
    });

    it('falls back to saved language when browser detection is unavailable', () => {
        expect(resolveGameLanguageDefault(null, { language: 'fr' }, 'en')).toBe('fr');
    });

    it('falls back to saved language when the detector throws', () => {
        const throwing = () => { throw new Error('no navigator'); };
        expect(resolveGameLanguageDefault(throwing, { language: 'es' }, 'en')).toBe('es');
    });

    it('falls back to the current default when nothing resolves', () => {
        expect(resolveGameLanguageDefault(null, null, 'en')).toBe('en');
        expect(resolveGameLanguageDefault(() => '', {}, 'en')).toBe('en');
    });
});

// ------------------------------------------------------------------
// buildTtsPayload — wizard finish must NOT wipe admin-owned keys (#1401)
// ------------------------------------------------------------------
describe('buildTtsPayload (#1401 — preserve tts_pre_round_delay)', () => {
    // Minimal stand-in for window.BeatifyTtsPresets (tts-settings.js).
    const presets = {
        KEYS: ['announce_game_start', 'announce_round_start'],
        presetValues: (name) => name === 'minimal'
            ? { announce_game_start: true, announce_round_start: false }
            : { announce_game_start: true, announce_round_start: true },
    };

    it('carries over an existing tts_pre_round_delay (#1211) on a preset finish', () => {
        // Admin had configured a 3s pre-round delay via tts-settings.js.
        const prev = { tts_pre_round_delay: 3, announce_game_start: false };
        const out = buildTtsPayload(prev, {
            enabled: true, entityId: 'tts.google', preset: 'standard', presets,
        });
        // The #1211 setting survives the wizard rebuild...
        expect(out.tts_pre_round_delay).toBe(3);
        // ...and the preset booleans are still applied.
        expect(out.enabled).toBe(true);
        expect(out.entity_id).toBe('tts.google');
        expect(out.preset).toBe('standard');
        expect(out.announce_game_start).toBe(true);
    });

    it('carries over tts_pre_round_delay on a custom-preset finish', () => {
        const prev = { tts_pre_round_delay: 1.5, announce_round_start: false };
        const out = buildTtsPayload(prev, {
            enabled: true, entityId: 'tts.google', preset: 'custom', presets,
        });
        expect(out.tts_pre_round_delay).toBe(1.5);
        // custom keeps hand-tuned booleans from prev
        expect(out.announce_round_start).toBe(false);
    });

    it('preserves a zero delay (0 is a valid configured value, not "unset")', () => {
        const out = buildTtsPayload({ tts_pre_round_delay: 0 }, {
            enabled: false, entityId: '', preset: 'minimal', presets,
        });
        expect(out.tts_pre_round_delay).toBe(0);
    });

    it('omits the key entirely when none was previously stored', () => {
        const out = buildTtsPayload({}, {
            enabled: true, entityId: 'tts.google', preset: 'standard', presets,
        });
        expect('tts_pre_round_delay' in out).toBe(false);
    });

    it('tolerates a null prev (private mode / first run)', () => {
        const out = buildTtsPayload(null, {
            enabled: true, entityId: 'tts.google', preset: 'standard', presets,
        });
        expect('tts_pre_round_delay' in out).toBe(false);
        expect(out.preset).toBe('standard');
    });
});

// ---------------------------------------------------------------------------
// modeHintHtml — the gated mode card explains itself without hover (#1799)
describe('modeHintHtml', () => {
    it('renders the mode description when the card is not gated', () => {
        const out = modeHintHtml(false, 'Needs at least 3 players', 'Last one out each round.');
        expect(out).toBe('<div class="wiz-mode-hint">Last one out each round.</div>');
        expect(out).not.toContain('gated');
    });

    it('replaces the description with the requirement when the card is gated', () => {
        const out = modeHintHtml(true, 'Needs at least 3 players', 'Last one out each round.');
        expect(out).toContain('wiz-mode-hint gated');
        expect(out).toContain('Needs at least 3 players');
        // The requirement must be visible on its own — not hidden behind hover.
        expect(out).not.toContain('Last one out each round.');
    });

    it('escapes the gate text', () => {
        const out = modeHintHtml(true, '<img src=x onerror=alert(1)>', 'hint');
        expect(out).not.toContain('<img');
        expect(out).toContain('&lt;img');
    });
});

// ---------------------------------------------------------------------------
// doneSummaryHtml — LAN-supplied names are escaped in the final summary (#2874,
// same rule as the speaker list in #1370)
describe('doneSummaryHtml (#2874)', () => {
    const t = (_key, fallback) => fallback;
    const base = {
        speaker: 'Esszimmer',
        provider: 'Spotify',
        playlistLabel: '80s Hits',
        modeSummary: 'Year mode · normal · 30s · EN',
        atmosphere: 'lights + voice',
    };

    it('renders normal names unchanged', () => {
        const out = doneSummaryHtml(base, t);
        expect(out).toContain('<span>Speaker</span><strong>Esszimmer</strong>');
        expect(out).toContain('<strong>80s Hits</strong>');
        expect(out.match(/<strong>((?:<span class="wiz-done-seg">[^<]*<\/span> ?)+)<\/strong>/)[1].replace(/<[^>]+>/g, '')).toBe('Year mode · normal · 30s · EN');
        expect(out).toContain('<strong>lights + voice</strong>');
    });

    it('escapes a crafted friendly_name and playlist name instead of rendering elements', () => {
        const out = doneSummaryHtml({
            ...base,
            speaker: '<img src=x onerror=alert(1)>',
            playlistLabel: '<b>Party</b> & more',
        }, t);
        expect(out).not.toContain('<img');
        expect(out).not.toContain('<b>');
        expect(out).toContain('<strong>&lt;img src=x onerror=alert(1)&gt;</strong>');
        expect(out).toContain('<strong>&lt;b&gt;Party&lt;/b&gt; &amp; more</strong>');
        // Only the summary's own markup is left as tags.
        const tags = out.match(/<\/?([a-z]+)/g).map((m) => m.replace(/[</]/g, ''));
        expect(new Set(tags)).toEqual(new Set(['div', 'span', 'strong']));
    });

    it('escapes provider, mode and atmosphere too', () => {
        const out = doneSummaryHtml({
            ...base,
            provider: '<svg onload=1>',
            modeSummary: '<i>x</i>',
            atmosphere: '<script>1</script>',
        }, t);
        expect(out).not.toMatch(/<(svg|i|script)\b/);
        expect(out).toContain('&lt;svg onload=1&gt;');
    });
});

describe('doneSummaryHtml mode line wraps between segments (#2995)', () => {
    const t = (_key, fallback) => fallback;
    const out = doneSummaryHtml({
        speaker: 'Esszimmer',
        provider: 'Spotify',
        playlistLabel: '80s Hits · Party',
        modeSummary: 'Jahres-Modus · normal · 45s · Alle Songs · DE',
        atmosphere: 'none',
    }, t);

    it('renders each mode segment as its own no-wrap span, dot kept on the left', () => {
        const segs = [...out.matchAll(/<span class="wiz-done-seg">([^<]*)<\/span>/g)].map((m) => m[1]);
        expect(segs).toEqual(['Jahres-Modus ·', 'normal ·', '45s ·', 'Alle Songs ·', 'DE']);
    });

    it('keeps the visible text exactly as before', () => {
        const mode = out.match(/<span>Mode<\/span><strong>(.*?)<\/strong>/)[1].replace(/<[^>]+>/g, '');
        expect(mode).toBe('Jahres-Modus · normal · 45s · Alle Songs · DE');
    });

    it('leaves the other lines as plain text (the playlist name is not split)', () => {
        expect(out).toContain('<strong>80s Hits · Party</strong>');
    });

    it('escapes each segment', () => {
        const x = doneSummaryHtml({ speaker: '', provider: '', playlistLabel: '', modeSummary: '<b>a</b> · b', atmosphere: '' }, t);
        expect(x).toContain('<span class="wiz-done-seg">&lt;b&gt;a&lt;/b&gt; ·</span>');
        expect(x).not.toContain('<b>');
    });

});

describe('#1940 — hiding the wizard refreshes the home view', () => {
    it('calls BeatifyHome.refresh() when the wizard is dismissed', async () => {
        const { hide } = await import('../wizard.js');
        const calls = [];
        const root = {
            classList: { add() {}, remove() {} },
            setAttribute() {},
        };
        globalThis.document = {
            getElementById: (id) => (id === 'wizard-root' ? root : null),
            body: { classList: { add() {}, remove() {} } },
        };
        globalThis.window = globalThis;
        globalThis.BeatifyHome = { refresh: () => calls.push('refresh') };
        globalThis.localStorage = {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
        };

        hide({ dismissed: true });

        // Skipping setup used to leave the home view on its "—" placeholder:
        // only the *completion* path called enter(), which refreshes.
        expect(calls).toEqual(['refresh']);
    });

    it('does not throw when the home view is not mounted', async () => {
        const { hide } = await import('../wizard.js');
        const root = { classList: { add() {}, remove() {} }, setAttribute() {} };
        globalThis.document = {
            getElementById: (id) => (id === 'wizard-root' ? root : null),
            body: { classList: { add() {}, remove() {} } },
        };
        globalThis.window = globalThis;
        delete globalThis.BeatifyHome;
        globalThis.localStorage = { getItem: () => null, setItem: () => {}, removeItem: () => {} };

        expect(() => hide({})).not.toThrow();
    });
});

// ------------------------------------------------------------------
// buildLightsPayload — what the wizard persists for party lights (#3159)
// ------------------------------------------------------------------
describe('buildLightsPayload', () => {
    const base = {
        entityIds: new Set(['light.a', 'light.b']),
        intensity: 'medium',
        mode: 'standard',
        wledPresets: {},
    };

    it('writes enabled:true and the entities when lights are on', () => {
        const p = buildLightsPayload({ ...base, enabled: true });
        expect(p.enabled).toBe(true);
        expect(p.lights).toEqual(['light.a', 'light.b']);
    });

    it('writes an explicit enabled:false but keeps the entities when lights are off (#3159)', () => {
        const p = buildLightsPayload({ ...base, enabled: false });
        expect(p.enabled).toBe(false);
        expect(p.lights).toEqual(['light.a', 'light.b']);
        expect(p.intensity).toBe('medium');
    });

    it('adds wled_presets only in wled mode with presets', () => {
        const presets = { start: 1 };
        expect(buildLightsPayload({ ...base, enabled: true, mode: 'wled', wledPresets: presets }).wled_presets).toEqual(presets);
        expect(buildLightsPayload({ ...base, enabled: true, mode: 'wled', wledPresets: {} })).not.toHaveProperty('wled_presets');
        expect(buildLightsPayload({ ...base, enabled: true, wledPresets: presets })).not.toHaveProperty('wled_presets');
    });
});
